document.addEventListener('DOMContentLoaded', () =>{
    
    
    const grid=document.querySelector('.grid')
    let squares=Array.from(document.querySelectorAll('.grid div'))
    const scoreDisplay=document.querySelector('#score')
    const startBtn=document.querySelector('#start-button')
    const leftBtn=document.querySelector('#left')
    const rightBtn=document.querySelector('#right')
    const downBtn=document.querySelector('#down')
    const rotateBtn=document.querySelector('#rotatee')
    const width=10
    let nextRandom=0
    let timerId
    let score=0
    const color=[
        '#564592',
        '#B2F7EF',
        '#B79CED',
        '#BF0603',
        '#DB5461'
    ]

    // tetris components

    const Ltetris=[
        [1, width+1, width*2+1, 2],
        [width, width+1, width+2, width*2+2],
        [1,width+1, width*2+1, width*2],
        [width, width*2, width*2+1, width*2+2]

    ]
      const Ztetris=[
        [0, width, width+1, width*2+1],
        [width+1, width+2, width*2, width*2+1],
        [0, width, width+1, width*2+1],
        [width+1, width+2, width*2, width*2+1]
    ]

    const Ttetris=[
        [1, width, width+1, width+2],
        [1, width+1, width+2, width*2+1],
        [width, width+1, width+2, width*2+1],
        [1, width, width+1, width*2+1]
    ]
    
    const squaretetris=[
        [0, 1, width, width+1],
        [0, 1, width, width+1],
        [0, 1, width, width+1],
        [0, 1, width, width+1]
    ]

    const Itetris=[
        [1, width+1, width*2+1, width*3+1],
        [width, width+1, width+2, width+3],
        [1, width+1, width*2+1, width*3+1],
        [width, width+1, width+2, width+3]
    ]

  

const allTetris=[Ltetris, Ztetris, Ttetris, squaretetris, Itetris]


let currentPosition=4
let currentRotation = 0
console.log(allTetris[0][0])


// chose random tetris shape
let random = Math.floor(Math.random()*allTetris.length)
let current=allTetris[random][currentRotation]

function draw(){
    current.forEach(index => {
        squares[currentPosition+index].classList.add('tetris')
        squares[currentPosition+index].style.backgroundColor=color[random]
    })
}

function undraw(){
    current.forEach(index =>{
        squares[currentPosition+index].classList.remove('tetris')
        squares[currentPosition+index].style.backgroundColor=''
    })
}

// move down time interval

// timerId=setInterval(moveDown,1000)

function moveDown(){
    undraw()
    currentPosition+=width
    draw()
    freeze()
}


// freeze the tetris

function freeze(){
    if(current.some(index => squares[currentPosition+index+width].classList.contains('taken'))){
        current.forEach(index => squares[currentPosition+index].classList.add('taken'))
        
    // new tetris will fall again
    random=nextRandom
        
    nextRandom=Math.floor(Math.random()*allTetris.length)
    current=allTetris[random][currentRotation]
    currentPosition=4
    draw()
    displayShape()
    addScore()
    gameOver()
    }

    
}


function moveLeft(){
    undraw()
    const isAtLeftEdge=current.some(index => (currentPosition+index) % width===0)

    if(!isAtLeftEdge) currentPosition-=1

    if(current.some( index=> squares[currentPosition+index].classList.contains('taken'))){
        currentPosition+=1

    }
    draw()
}
function moveRight(){
    undraw()
    const isAtRightEdge=current.some(index => (currentPosition+index) % width===width-1)

    if(!isAtRightEdge) currentPosition+=1

    if(current.some( index=> squares[currentPosition+index].classList.contains('taken'))){
        currentPosition-=1

    }
    draw()
}
function rotate(){
    undraw()
  currentRotation++
  if(currentRotation===current.length){
      currentRotation=0

  }
  current = allTetris[random][currentRotation]
  draw()
}






function control(e){
if(e.keyCode===37 || e.keyCode===65){
    moveLeft()
}
else if(e.keyCode===38 || e.keyCode===32){
    rotate()
}
else if(e.keyCode===39 || e.keyCode===68){
    moveRight()
}
else if(e.keyCode===40 || e.keyCode===83){
    moveDown()
}

}
document.addEventListener('keyup', control)




//display

const displaySquare=document.querySelectorAll('.mini-grid div')
const displayWidth=4
const displayIndex=0


const upNextTetris=[
    [1, displayWidth+1, displayWidth*2+1, 2],
    [0, displayWidth, displayWidth+1, displayWidth*2+1],
    [1, displayWidth, displayWidth+1, displayWidth+2],
    [0,1,displayWidth, displayWidth+1 ],
    [1, displayWidth+1, displayWidth*2+1, displayWidth*3+1]
]

function displayShape(){
    displaySquare.forEach(square => {
        square.classList.remove('tetris')
        square.style.backgroundColor =''
    })

    upNextTetris[nextRandom].forEach(index=>{
        displaySquare[displayIndex+index].classList.add('tetris')
        displaySquare[displayIndex+index].style.backgroundColor=color[nextRandom]
    })
}




// start and pause

startBtn.addEventListener('click', () =>{
    if(timerId){
        clearInterval(timerId)
        timerId=null
    }
    else{
        draw()
        timerId=setInterval(moveDown, 1000)
        nextRandom=Math.floor(Math.random()*allTetris.length)
        displayShape()
    }

})

leftBtn.addEventListener('click', ()=>{
moveLeft()
})
rightBtn.addEventListener('click', ()=>{
moveRight()
})
downBtn.addEventListener('click', ()=>{
moveDown()
})
rotateBtn.addEventListener('click', ()=>{
rotate()
})

// add Score

function addScore(){
    for(let i=0; i<199;i+=width){
        const row =[i, i+1, i+2, i+3, i+4, i+5, i+6, i+7, i+8, i+9]


        if(row.every(index =>squares[index].classList.contains('taken'))){
            score +=10
            scoreDisplay.innerHTML=score
            row.forEach(index => {
                squares[index].classList.remove('taken')
                squares[index].classList.remove('tetris')
                squares[index].style.backgroundColor=''
            })
            const squareRemove = squares.splice(i, width)
            squares = squareRemove.concat(squares)
            squares.forEach(cell=>grid.appendChild(cell))
        }
    }
}

// game over setting
function gameOver(){
    if(current.some(index => squares[currentPosition+index].classList.contains('taken'))){
        scoreDisplay.innerHTML=' Game Over Buddy!'
        clearInterval(timerId)
    }
}

})